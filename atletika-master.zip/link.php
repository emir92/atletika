<!doctype html>
<? php 
	include 'config.php';
	session_start();
?>
<html>
<head>
	<link rel="stylesheet" href="stillogo.css">
	<link rel="stylesheet" href="stil.css">
	
</head>
<body>
	<header>
		<div class="wrap">
		<div class="logoHead"></div>
		<div class="logoBody"></div>
		<div class="logoArmLefta"></div>
		<div class="logoArmLeftb"></div>
		<div class="logoArmRighta"></div>
		<div class="logoArmRightb"></div>
		<div class="logoLegLefta"></div>
		<div class="logoLegLeftb"></div>
		<div class="logoLegRighta"></div>
		<div class="logoLegRightb"></div>
		</div>
	</header>
	<nav>
		<ul id="navul">
			<li id="navli"><a id="nava" href="index.html">HOME</a></li>
			<li class="active" id="navli"><a id="nava" href="link.html">LINK</a></li>
			<li id="navli"><a id="nava" href="contactus.html">CONTACT US</a></li>
			<li id="navli"><a id="nava" href="tabel.html">TABEL</a></li>
		</ul>
	</nav>
	<ul id="linkovi">
		<li id="linkovili"><a href="http://www.etf.unsa.ba">ETF</a></li>
		<li id="linkovili"><a href="http://www.w3schools.com/">W3SCHOOL</a></li>
		<li id="linkovili"><a href="http://www.facebok.com">FACEBOOK</a></li>
		<li id="linkovili"><a href="http://www.klix.ba">KLIX</a></li>
		<li id="linkovili"><a href="http://www.iaaf.org">IAFF</a></li>
	</ul>
	<footer>
		<ul id="navul">
			<li id="navli"><a id="nava" href="index.html">HOME</a></li>
			<li class="active" id="navli"><a id="nava" href="link.html">LINK</a></li>
			<li id="navli"><a id="nava" href="contactus.html">CONTACT US</a></li>
			<li id="navli"><a id="nava" href="tabel.html">TABEL</a></li>
		</ul>
	</footer>
</body>
</html>