<!doctype html>
<? php 
	include 'config.php';
	session_start();
?>
<html>
<head>
	<link rel="stylesheet" href="stillogo.css">
	<link rel="stylesheet" href="stil.css">
	
</head>
<body>
	<header>
		<div class="wrap">
		<div class="logoHead"></div>
		<div class="logoBody"></div>
		<div class="logoArmLefta"></div>
		<div class="logoArmLeftb"></div>
		<div class="logoArmRighta"></div>
		<div class="logoArmRightb"></div>
		<div class="logoLegLefta"></div>
		<div class="logoLegLeftb"></div>
		<div class="logoLegRighta"></div>
		<div class="logoLegRightb"></div>
		</div>
	</header>
	<nav>
		<ul id="navul">
			<li id="navli"><a id="nava" href="index.html">HOME</a></li>
			<li id="navli"><a id="nava" href="link.html">LINK</a></li>
			<li class="active" id="navli"><a id="nava" href="contactus.html">CONTACT US</a></li>
			<li id="navli"><a id="nava" href="tabel.html">TABEL</a></li>
		</ul>
	</nav>
	<form action="url:www.etf.unsa.ba"><center>	
		<fieldset>
			<label>Ime</label></br>
			<input type="text" name="ime" placeholder="Niko"></br>
			<label>Prezime</label></br>
			<input type="text" name="prezime" placeholder="Niković"></br>
			<label for="">E-mail</label></br>
			<input type="text" name="email" placeholder="ono@kao.nesto" ></br></br>
			<input type="submit"></br>
		</fieldset>
		</center>
	</form>
	<footer>
		<ul id="navul">
			<li id="navli"><a id="nava" href="index.html">HOME</a></li>
			<li id="navli"><a id="nava" href="link.html">LINK</a></li>
			<li class="active" id="navli"><a id="nava" href="contactus.html">CONTACT US</a></li>
			<li id="navli"><a id="nava" href="tabel.html">TABEL</a></li>
		</ul>
	</footer>
</body>
</html>