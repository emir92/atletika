<!doctype html>
<? php 
	include 'config.php';
	session_start();
?>
<html>
<head>
	<link rel="stylesheet" href="stillogo.css">
	<link rel="stylesheet" href="stil.css">
	
</head>
<body>
	<header>
		<div class="wrap">
		<div class="logoHead"></div>
		<div class="logoBody"></div>
		<div class="logoArmLefta"></div>
		<div class="logoArmLeftb"></div>
		<div class="logoArmRighta"></div>
		<div class="logoArmRightb"></div>
		<div class="logoLegLefta"></div>
		<div class="logoLegLeftb"></div>
		<div class="logoLegRighta"></div>
		<div class="logoLegRightb"></div>
		</div>
	</header>
	<nav>
		<ul id="navul">
			<li class="active" id="navli"><a id="nava" href="index.html">HOME</a></li>
			<li id="navli"><a id="nava" href="link.html">LINK</a></li>
			<li id="navli"><a id="nava" href="contactus.html">CONTACT US</a></li>
			<li id="navli"><a id="nava" href="tabel.html">TABEL</a></li>
		</ul>
	</nav>
	<ul id="vjesti">
		<li id="vjestili">
			<article>	
				<h1>Breaking news</h1>
				<p><strong>Author:</strong> Bill Clinton, <strong>Published:</strong> Yesterday</p>
				<div class="image-wrapper">
					<img src="http://balkans.aljazeera.net/sites/staff.balkans.aljazeera.com/files/styles/aljazeera_article_main_image/public/tuka-amel-getty1-main.jpg" alt="Amel Tuka">
					<span>Image Source Al Jazeera</span>
				</div>
				<p>
                This paragraph will include the photo of a random cat that the author of this tutorial has found online. You can replace this text with any random text. The sole purpose of this copy is to fill the space and make sure that the image to the left has enough text to low around it. I even decided to copy the previous paragraph. This paragraph will include the photo of a random cat that the author of this tutorial has found online. You can replace this text with any random text. The sole purpose of this copy is to fill the space and make sure that the image to the left has enough text to low around it.
            </p>
            <p>This paragraph will include the photo of a random cat that the author of this tutorial has found online. You can replace this text with any random text. The sole purpose of this copy is to fill the space and make sure that the image to the left has enough text fo low around it.</p>
			</article>
		</li>
		<li id="vjestili"> 
			<article>
				<h1>Last news</h1>
				<p><strong>Author:</strong> Bill Clinton, <strong>Published:</strong> Yesterday</p>
				<div class="image-wrapper">
					<img src="http://balkans.aljazeera.net/sites/staff.balkans.aljazeera.com/files/styles/aljazeera_article_main_image/public/tuka-amel-getty1-main.jpg" alt="Amel Tuka">
					<span>Image Source Al Jazeera</span>
				</div>
				<p>
                This paragraph will include the photo of a random cat that the author of this tutorial has found online. You can replace this text with any random text. The sole purpose of this copy is to fill the space and make sure that the image to the left has enough text to low around it. I even decided to copy the previous paragraph. This paragraph will include the photo of a random cat that the author of this tutorial has found online. You can replace this text with any random text. The sole purpose of this copy is to fill the space and make sure that the image to the left has enough text to low around it.
            </p>
            <p>This paragraph will include the photo of a random cat that the author of this tutorial has found online. You can replace this text with any random text. The sole purpose of this copy is to fill the space and make sure that the image to the left has enough text fo low around it.</p>
			</article>
		</li>
		<li id="vjestili">
			<article>	
				<h1>Breaking news</h1>
				<p><strong>Author:</strong> Bill Clinton, <strong>Published:</strong> Yesterday</p>
				<div class="image-wrapper">
					<img src="http://balkans.aljazeera.net/sites/staff.balkans.aljazeera.com/files/styles/aljazeera_article_main_image/public/tuka-amel-getty1-main.jpg" alt="Amel Tuka">
					<span>Image Source Al Jazeera</span>
				</div>
				<p>
                This paragraph will include the photo of a random cat that the author of this tutorial has found online. You can replace this text with any random text. The sole purpose of this copy is to fill the space and make sure that the image to the left has enough text to low around it. I even decided to copy the previous paragraph. This paragraph will include the photo of a random cat that the author of this tutorial has found online. You can replace this text with any random text. The sole purpose of this copy is to fill the space and make sure that the image to the left has enough text to low around it.
            </p>
            <p>This paragraph will include the photo of a random cat that the author of this tutorial has found online. You can replace this text with any random text. The sole purpose of this copy is to fill the space and make sure that the image to the left has enough text fo low around it.</p>
			</article>
		</li>
		<li id="vjestili"> 
			<article>
				<h1>Last news</h1>
				<p><strong>Author:</strong> Bill Clinton, <strong>Published:</strong> Yesterday</p>
				<div class="image-wrapper">
					<img src="http://balkans.aljazeera.net/sites/staff.balkans.aljazeera.com/files/styles/aljazeera_article_main_image/public/tuka-amel-getty1-main.jpg" alt="Amel Tuka">
					<span>Image Source Al Jazeera</span>
				</div>
				<p>
                This paragraph will include the photo of a random cat that the author of this tutorial has found online. You can replace this text with any random text. The sole purpose of this copy is to fill the space and make sure that the image to the left has enough text to low around it. I even decided to copy the previous paragraph. This paragraph will include the photo of a random cat that the author of this tutorial has found online. You can replace this text with any random text. The sole purpose of this copy is to fill the space and make sure that the image to the left has enough text to low around it.
            </p>
            <p>This paragraph will include the photo of a random cat that the author of this tutorial has found online. You can replace this text with any random text. The sole purpose of this copy is to fill the space and make sure that the image to the left has enough text fo low around it.</p>
			</article>
		</li>
	</ul>
	<footer>
		<ul id="navul">
			<li class="active" id="navli"><a id="nava" href="index.html">HOME</a></li>
			<li id="navli"><a id="nava" href="link.html">LINK</a></li>
			<li id="navli"><a id="nava" href="contactus.html">CONTACT US</a></li>
			<li id="navli"><a id="nava" href="tabel.html">TABEL</a></li>
		</ul>
	</footer>
</body>
</html>