<!doctype html>
<? php 
	include 'config.php';
	session_start();
?>
<html>
<head>
	<link rel="stylesheet" href="stillogo.css">
	<link rel="stylesheet" href="stil.css">
	
</head>
<body>
	<header>
		<div class="wrap">
		<div class="logoHead"></div>
		<div class="logoBody"></div>
		<div class="logoArmLefta"></div>
		<div class="logoArmLeftb"></div>
		<div class="logoArmRighta"></div>
		<div class="logoArmRightb"></div>
		<div class="logoLegLefta"></div>
		<div class="logoLegLeftb"></div>
		<div class="logoLegRighta"></div>
		<div class="logoLegRightb"></div>
		</div>
	</header>
	<nav>
		<ul id="navul">
			<li id="navli"><a id="nava" href="index.html">HOME</a></li>
			<li id="navli"><a id="nava" href="link.html">LINK</a></li>
			<li id="navli"><a id="nava" href="contactus.html">CONTACT US</a></li>
			<li class="active" id="navli"><a id="nava" href="tabel.html">TABEL</a></li>
		</ul>
	</nav>
	
	<table>
		<tr>
			<th>Meeting name</th>
			<th>Competition Category </th>
			<th>Venue</th>
			<th>Country</th>
			<th>Date</th>
		</tr>
		<tr id="nepar">
			<td>Bosnia Open</td>
			<td>Balkan</td>
			<td>Zenica</td>
			<td>BIH</td>
			<td>21.Mart</td>
		</tr>
		<tr id="par">
			<td>Zurich</td>
			<td>Diamont Legue</td>
			<td>Zurich</td>
			<td>SUI</td>
			<td>18.Decembar</td>
		</tr>
		<tr id="nepar">
			<td>Paris</td>
			<td>Diamont Legue</td>
			<td>Paris</td>
			<td>FRA</td>
			<td>21.Septembar</td>
		</tr>
		<tr id="par">
			<td>Zagreb</td>
			<td>Balkan</td>
			<td>Zagreb</td>
			<td>CRO</td>
			<td>1.Maj</td>
		</tr>
	</table>
	
	<footer>
		<ul id="navul">
			<li id="navli"><a id="nava" href="index.html">HOME</a></li>
			<li id="navli"><a id="nava" href="link.html">LINK</a></li>
			<li id="navli"><a id="nava" href="contactus.html">CONTACT US</a></li>
			<li class="active" id="navli"><a id="nava" href="tabel.html">TABEL</a></li>
		</ul>
	</footer>
</body>
</html>