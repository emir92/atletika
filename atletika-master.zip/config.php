<?php
	session_start)();
	if(!isset($_SESSION["isLogIn"])){
		$_SESSION["isLogIn"]="false";
	}
	
	function login(){
		$path= "users.txt";
		$file= fopen($path, "r");
		
		while(!feof($file)){
			$row=fgets($file);
			$brojac= strpos($row, ",",0);
			$user= trim(substr($row,0,$brojac));
			$pass= trim(substr($row, $brojac+1));
			if(isset($_POST["username"]) && isset($_POST["password"])){
				$username= $_POST["username"];
				$password= md5($_POST["password"]);
				if ($username == $user && $password == $pass) $_SESSION["isLogIn"]="true";
			}
		}
	}
	
	$akcija="";
	
	if ($akcija== "login") login();
	if ($akcija== "logout") {
		session_destroy();
		$_SESSION["isLogIn"]="false";
	}
	
?>